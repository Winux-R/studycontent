export const VOTE_SUPPORT = 'VOTE_SUPPORT';
export const VOTE_AGAINST = 'VOTE_AGAINST';

export const PERSON_BASE = 'PERSON_BASE';