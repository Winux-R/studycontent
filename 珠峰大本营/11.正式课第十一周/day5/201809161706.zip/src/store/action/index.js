import vote_action from './vote';
import person_action from './person';

let action = {
    vote: vote_action,
    person: person_action
};
export default action;