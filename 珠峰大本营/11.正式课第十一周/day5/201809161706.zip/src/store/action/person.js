import * as TYPES from '../action-types';

let person_action = {};
export default person_action;