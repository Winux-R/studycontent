import React from 'react';
import ReactDOM from 'react-dom';
import Vote from "./component/Vote";
import 'bootstrap/dist/css/bootstrap.css';

ReactDOM.render(<div>
    <Vote title='王伟常丑不丑？'/>
</div>, window.root);

