import vote_action from './vote';

let action = {
    vote: vote_action
};
export default action;